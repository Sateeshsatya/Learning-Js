# News-app
Simple news app using newsapi.org
